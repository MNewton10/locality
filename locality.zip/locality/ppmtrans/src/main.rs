use clap::Parser;
#[derive(Parser, Debug)]
#[clap(author, version, about, long_about = None)]
struct Args {
// Flip
    #[clap(long = "flip", required = false)]
    flip: Option<String>,
    // Rotation
    #[clap(short = 'r', long = "rotate")]
    rotate: Option<u32>,
    // Transposition
    #[clap(long = "transpose")]
    transpose: bool,
    // Row Major
    #[clap(long = "row_major")]
    row_major: bool,
    // Column Major
    #[clap(long = "col_major")]
    column_major: bool,
}

fn rotate_90(major: String) -> Array2 {
    let new_width = self.height();
    let new_height = self.width();
    let new_img = Array2::from_row_major(new_width, new_height, Vec<Rgb>);
    if major == "row_major" {
        for row in self.iter_row_major() {
            for data in row {
                new_img[(self.height() - col - 1) * new_img.width() + row] = data.clone();
            }
        }
    }
    else if major == "col_major" {
        for col in self.iter_col_major() {
            for data in col {
                new_img[(self.height() - col - 1) * new_img.width() + row] = data.clone();
            }
        }
    }
}

fn rotate_180(major: String) -> Array2 {
    let new_width = self.height();
    let new_height = self.width();
    let new_img = Array2::from_row_major(new_width, new_height, Vec<Rgb>);
    if major == "row_major" {
        for row in new_img.iter_row_major() {
            new_img
        }
    }
}

fn main() {
let args = Args::parse();
let rotate = args.rotate;

}
